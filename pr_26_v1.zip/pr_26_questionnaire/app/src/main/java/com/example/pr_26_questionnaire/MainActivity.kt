package com.example.pr_26_questionnaire

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    EditText phoneNumber = (EditText) findViewById(R.id.phone);
    phoneNumber.addTextChangedListener(new TextWatcher() {
        final static String DELIMITER = "-";
        String lastChar;

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            int digits = phoneNumber.getText().toString().length();
            if (digits > 1)
                lastChar = phoneNumber.getText().toString().substring(digits-1);
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            int digits = phoneNumber.getText().length();
            if (digits > 0 && digits != 4 && digits != 8) {
                CharSequence last = s.subSequence(digits - 1, digits);
                if (last.toString().equals(DELIMITER))
                    phoneNumber.getText().delete(digits - 1, digits);
            }
            if (digits == 3 || digits == 7) {
                if (!lastChar.equals(DELIMITER))
                    phoneNumber.append("-");
                else
                    phoneNumber.getText().delete(digits -1, digits);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {}
    });

}